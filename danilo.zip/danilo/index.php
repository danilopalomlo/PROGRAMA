<?php 
    include_once('Templates/header.php');
    include_once('Templates/facturaTemplate.php');
    include_once('Templates/footer.php');
?>